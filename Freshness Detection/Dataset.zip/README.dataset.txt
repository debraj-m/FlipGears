# fruits > 2024-10-19 1:04pm
https://universe.roboflow.com/bodydetectionsih/fruits-wkspq

Provided by a Roboflow user
License: CC BY 4.0

