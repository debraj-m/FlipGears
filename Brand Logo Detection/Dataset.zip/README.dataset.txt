# Brand Logo Detection > 2024-10-09 8:54am
https://universe.roboflow.com/bodydetectionsih/brand-logo-detection-rupy9

Provided by a Roboflow user
License: CC BY 4.0

